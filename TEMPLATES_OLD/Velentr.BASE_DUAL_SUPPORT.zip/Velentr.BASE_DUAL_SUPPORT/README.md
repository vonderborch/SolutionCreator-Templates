# [SOLUTIONNAME]
[DESCRIPTION]

# Installation
There are nuget packages available for Monogame and FNA:
- Monogame [![NuGet version ([SOLUTIONNAME].Monogame)](https://img.shields.io/nuget/v/[SOLUTIONNAME].Monogame.svg?style=flat-square)](https://www.nuget.org/packages/[SOLUTIONNAME].Monogame/): [[SOLUTIONNAME].Monogame](https://www.nuget.org/packages/[SOLUTIONNAME].Monogame/)
- FNA [![NuGet version ([SOLUTIONNAME].FNA)](https://img.shields.io/nuget/v/[SOLUTIONNAME].FNA.svg?style=flat-square)](https://www.nuget.org/packages/[SOLUTIONNAME].FNA/): [[SOLUTIONNAME].FNA](https://www.nuget.org/packages/[SOLUTIONNAME].FNA/)

# Future Plans
See list of issues under the Milestones: https://github.com/vonderborch/[SOLUTIONNAME]/milestones