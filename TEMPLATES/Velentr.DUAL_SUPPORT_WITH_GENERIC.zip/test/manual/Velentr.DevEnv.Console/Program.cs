using System;

namespace Velentr.DevEnv.Console
{
    class Program
    {
        static void Main(string[] args)
        {
            // insert test code here
        }
    }
}
