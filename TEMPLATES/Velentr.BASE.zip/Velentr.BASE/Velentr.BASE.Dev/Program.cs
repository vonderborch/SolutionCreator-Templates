﻿using System;

namespace Velentr.BASE.dev
{
    class Program
    {
        static void Main(string[] args)
        {
            // insert test code here
        }
    }
}
