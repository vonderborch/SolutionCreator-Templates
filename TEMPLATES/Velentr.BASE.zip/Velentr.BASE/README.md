# [SOLUTIONNAME]
[DESCRIPTION]

# Installation
[![NuGet version ([SOLUTIONNAME])](https://img.shields.io/nuget/v/[SOLUTIONNAME].svg?style=flat-square)](https://www.nuget.org/packages/[SOLUTIONNAME]/)

A nuget package is available: [[SOLUTIONNAME]](https://www.nuget.org/packages/[SOLUTIONNAME]/)

# Future Plans
See list of issues under the Milestones: https://github.com/vonderborch/[SOLUTIONNAME]/milestones