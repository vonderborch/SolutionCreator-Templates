# Velentr.DUAL_SUPPORT
A library

# Installation
There are nuget packages available for Monogame and FNA:
- Monogame [![NuGet version (Velentr.DUAL_SUPPORT.Monogame)](https://img.shields.io/nuget/v/Velentr.DUAL_SUPPORT.Monogame.svg?style=flat-square)](https://www.nuget.org/packages/Velentr.DUAL_SUPPORT.Monogame/): [Velentr.DUAL_SUPPORT.Monogame](https://www.nuget.org/packages/Velentr.DUAL_SUPPORT.Monogame/)
- FNA [![NuGet version (Velentr.DUAL_SUPPORT.FNA)](https://img.shields.io/nuget/v/Velentr.DUAL_SUPPORT.FNA.svg?style=flat-square)](https://www.nuget.org/packages/Velentr.DUAL_SUPPORT.FNA/): [Velentr.DUAL_SUPPORT.FNA](https://www.nuget.org/packages/Velentr.DUAL_SUPPORT.FNA/)

# Future Plans
See list of issues under the Milestones: https://github.com/vonderborch/Velentr.DUAL_SUPPORT/milestones
